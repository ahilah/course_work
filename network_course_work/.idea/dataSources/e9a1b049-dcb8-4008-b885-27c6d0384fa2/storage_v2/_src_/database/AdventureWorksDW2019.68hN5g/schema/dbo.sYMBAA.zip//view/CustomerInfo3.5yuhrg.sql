CREATE VIEW CustomerInfo3 AS
SELECT
COUNT(CustomerKey) AS NumberCustomers,
NumberM  = (SELECT COUNT(*) FROM [dbo].[DimCustomer] WHERE EnglishEducation LIKE '%High School%' AND MaritalStatus = 'M'),
NumberS = (SELECT COUNT(*) FROM [dbo].[DimCustomer] WHERE EnglishEducation LIKE '%High School%' AND MaritalStatus = 'S'),
DATEDIFF(yy, MAX(BirthDate), GETDATE()) AS CustomerMinAge,
DATEDIFF(yy, MIN(BirthDate), GETDATE()) AS CustomerMaxAge,
MAX(YearlyIncome) AS MaxIncome,
MIN(YearlyIncome) AS MinIncome,
AVG(YearlyIncome) AS AvgIncome
FROM [dbo].[DimCustomer]
WHERE EnglishEducation LIKE '%High School%'
go

