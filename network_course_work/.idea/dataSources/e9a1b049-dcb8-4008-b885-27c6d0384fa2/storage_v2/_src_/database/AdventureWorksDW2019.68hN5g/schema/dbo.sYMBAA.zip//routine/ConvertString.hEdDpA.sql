
CREATE FUNCTION ConvertString(@string varchar(20)) -- создать функцию
RETURNS varchar(30)
AS
BEGIN 
DECLARE @NewString varchar(30) = TRIM(@string)
RETURN '%' + @NewString + '%'; 
END; 
go

