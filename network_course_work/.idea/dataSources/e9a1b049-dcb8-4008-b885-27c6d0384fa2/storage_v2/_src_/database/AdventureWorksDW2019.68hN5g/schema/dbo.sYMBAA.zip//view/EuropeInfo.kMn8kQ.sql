
CREATE VIEW EuropeInfo AS
SELECT
[SalesTerritoryGroup],
[SalesTerritoryCountry],
FIS.[TotalProductCost],
DATEPART(yy, FIS.OrderDate) AS [Year],
[TaxAmt],
[SalesAmount]
FROM [dbo].[FactInternetSales] AS FIS
INNER JOIN [dbo].[DimSalesTerritory] AS DST
ON FIS.SalesTerritoryKey = DST.SalesTerritoryKey
WHERE DST.SalesTerritoryGroup LIKE '%Europe%'
go

