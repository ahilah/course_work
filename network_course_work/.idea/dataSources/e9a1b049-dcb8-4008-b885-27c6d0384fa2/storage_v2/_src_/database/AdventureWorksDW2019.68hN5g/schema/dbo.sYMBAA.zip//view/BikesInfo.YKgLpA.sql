

CREATE VIEW BikesInfo AS
SELECT
[ProductKey],
[ProductAlternateKey],
[EnglishProductName],
[EnglishProductSubcategoryName],
[Color],
[SafetyStockLevel],
[ReorderPoint],
[ListPrice],
[Size],
[SizeRange],
[Weight],
[DaysToManufacture],
[ProductLine],
[DealerPrice],
[Class],
[Style],
[ModelName]
FROM [dbo].[DimProduct] DP
INNER JOIN [dbo].[DimProductSubcategory] DPS
ON DP.ProductSubcategoryKey = DPS.ProductSubcategoryKey
INNER JOIN [dbo].[DimProductCategory] DPC
ON DPC.ProductCategoryKey = DPS.ProductCategoryKey
WHERE DPC.EnglishProductCategoryName LIKE '%bike%'
go

