
CREATE FUNCTION GetCustInfo(@CustKey int)
RETURNS TABLE 
AS
RETURN (
	SELECT 
		MAX(al1.OrderDate) AS OrderDate,
		COUNT(*) AS OrderNumber
	FROM [dbo].[FactInternetSales] al1 INNER JOIN [dbo].[FactInternetSales] al2
	ON al1.CustomerKey = al2.CustomerKey
	WHERE al1.CustomerKey = @CustKey
); 
go

