CREATE FUNCTION LastCustOrder1(@email varchar(100))
RETURNS DATE
AS
BEGIN 
RETURN (
	SELECT 
		MAX(OrderDate)
	FROM [dbo].[DimCustomer] al1
	INNER JOIN [dbo].[FactInternetSales] al2
	ON al1.CustomerKey = al2.CustomerKey
	WHERE EmailAddress = @email)
END
go

