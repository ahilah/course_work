CREATE VIEW EuropeInfo4 AS
SELECT
[SalesTerritoryCountry],
SUM(FIS.[TotalProductCost]) AS TotalProductCost,
DATEPART(yy, FIS.OrderDate) AS [Year],
OrderNumber = COUNT([SalesTerritoryCountry]),
SUM([TaxAmt]) AS SumTaxAmt,
AVG([SalesAmount]) AS AvgSalesAmount
FROM [dbo].[FactInternetSales] AS FIS
INNER JOIN [dbo].[DimSalesTerritory] AS DST
ON FIS.SalesTerritoryKey = DST.SalesTerritoryKey
WHERE DST.SalesTerritoryGroup LIKE '%Europe%'
GROUP BY [SalesTerritoryCountry], DATEPART(yy, FIS.OrderDate), [SalesTerritoryCountry]
go

