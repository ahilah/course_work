CREATE FUNCTION AddDay(@NumberDays int, @Date DATE)
RETURNS  DATE
AS
BEGIN 
RETURN DATEADD (day, @NumberDays, @Date)
END
go

