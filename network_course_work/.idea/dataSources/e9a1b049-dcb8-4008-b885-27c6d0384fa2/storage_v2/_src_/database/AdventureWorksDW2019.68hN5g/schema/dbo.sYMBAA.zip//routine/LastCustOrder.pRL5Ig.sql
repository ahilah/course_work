CREATE FUNCTION LastCustOrder(@email varchar(100))
RETURNS DATE
AS
BEGIN 
RETURN (
	SELECT 
		MAX(al1.OrderDate) AS OrderDate
	FROM [dbo].[FactInternetSales] al1 INNER JOIN [dbo].[FactInternetSales] al2
	ON al1.CustomerKey = al2.CustomerKey
	WHERE al1.CustomerKey = (SELECT CustomerKey FROM [dbo].[DimCustomer] WHERE EmailAddress = @email)
)
END
go

