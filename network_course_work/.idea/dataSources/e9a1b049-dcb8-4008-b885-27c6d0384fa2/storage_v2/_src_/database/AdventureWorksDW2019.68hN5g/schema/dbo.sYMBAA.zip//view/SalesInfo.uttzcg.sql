
CREATE VIEW SalesInfo AS
SELECT
DP.ProductKey,
DPC.ProductCategoryKey,
DPS.ProductSubcategoryKey,
COUNT (DP.ProductKey) AS NumberOrdersProduct,
SUM(FIS.OrderQuantity) AS NumberSoldProducts
FROM [dbo].[DimProduct] AS DP
INNER JOIN [dbo].[DimProductSubcategory] AS DPS
ON DP.ProductSubcategoryKey = DPS.ProductSubcategoryKey
INNER JOIN [dbo].[DimProductCategory] AS DPC
ON DPS.ProductCategoryKey = DPC.ProductCategoryKey
INNER JOIN [dbo].[FactInternetSales] AS FIS
ON DP.ProductKey = FIS.ProductKey
WHERE YEAR(OrderDate) = 2013
GROUP BY DP.ProductKey, DPC.ProductCategoryKey, DPS.ProductSubcategoryKey
go

