CREATE VIEW CustomerInfo1 AS
SELECT
COUNT(CustomerKey) AS NumberCustomers,
COUNT(MaritalStatus) AS NumberM,
COUNT(MaritalStatus) AS NumberS,
DATEDIFF(yy, MAX(BirthDate), GETDATE()) AS CustomerMinAge,
DATEDIFF(yy, MIN(BirthDate), GETDATE()) AS CustomerMaxAge,
MAX(YearlyIncome) AS MaxIncome,
MIN(YearlyIncome) AS MinIncome,
AVG(YearlyIncome) AS AvgIncome
FROM [dbo].[DimCustomer]
WHERE EnglishEducation LIKE '%High School%'
go

