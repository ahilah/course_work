
CREATE VIEW CustomerInfo AS
SELECT * FROM [dbo].[DimCustomer]
go

