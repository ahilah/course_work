
CREATE VIEW CustonerInfo AS
SELECT
COUNT(CustomerKey) AS NumberCustomers,
COUNT(MaritalStatus) AS NumberM,
COUNT(MaritalStatus) AS NumberS,
DATEDIFF(yy, MAX(BirthDate), GETDATE()) AS CustomerMinAge,
DATEDIFF(yy, MIN(BirthDate), GETDATE()) AS CustomerMaxAge
FROM [dbo].[DimCustomer]
WHERE EnglishEducation LIKE '%High School%'

go

