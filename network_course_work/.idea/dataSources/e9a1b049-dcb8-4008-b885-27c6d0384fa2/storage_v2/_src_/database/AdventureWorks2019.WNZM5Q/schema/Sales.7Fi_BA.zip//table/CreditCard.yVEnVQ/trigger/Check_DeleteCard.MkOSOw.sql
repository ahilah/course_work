CREATE TRIGGER Check_DeleteCard
ON [Sales].[CreditCard]
INSTEAD OF DELETE
AS
BEGIN 
	SET NOCOUNT ON;
	DECLARE @ID int
	SELECT @ID = deleted.CreditCardID
	FROM deleted
	IF (
		SELECT COUNT(CreditCardID)
		FROM [Sales].[PersonCreditCard]
		WHERE CreditCardID = @ID) = 1
	BEGIN
		RAISERROR('----- Delete error -----', 16, 1)
	END
	ELSE
	BEGIN
		DELETE FROM [Sales].[CreditCard]
		WHERE CreditCardID = @ID
	END
END
go

