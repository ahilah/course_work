CREATE TRIGGER Check_DeleteCard
ON [Production].[Product]
INSTEAD OF UPDATE
AS
BEGIN 
	DECLARE @ID int,
	@Price int
	SELECT @ID = inserted.ProductID,
		   @Price = inserted.ListPrice
	FROM inserted
	IF @Price >= 1.15 * (
					SELECT
					ListPrice
					FROM [Production].[Product]
					WHERE ProductID = @ID)
	BEGIN
		RAISERROR('----- Update error -----', 16, 1)
	END
	ELSE
	BEGIN
		UPDATE [Production].[Product]
		SET ListPrice = @Price
		WHERE ProductID = @ID
	END
END
go

