CREATE TRIGGER Update_Products
ON [Production].[Product]
AFTER UPDATE
AS IF UPDATE(ListPrice)
BEGIN 
	DECLARE @ProductName varchar(150),
			@ID int,
			@NewPrice int,
			@OldPrice int
	SELECT @NewPrice = inserted.ListPrice
	FROM inserted
	SELECT @ProductName = deleted.[Name],
		   @ID = deleted.ProductID,
		   @OldPrice = deleted.ListPrice
		   FROM deleted
INSERT INTO [HistPr].History
VALUES(@ID, @ProductName, @OldPrice, @NewPrice, GETDATE())
END
go

