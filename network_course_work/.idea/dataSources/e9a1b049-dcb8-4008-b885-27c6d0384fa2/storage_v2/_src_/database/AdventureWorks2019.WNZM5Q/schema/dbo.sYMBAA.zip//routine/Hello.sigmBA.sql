
CREATE FUNCTION Hello() -- создать функцию
RETURNS varchar(30)
-- объявляем тип возвращаемого значения
AS
BEGIN -- начало тела функции
DECLARE @MyVar varchar(20) = 'Hello World!';
RETURN @MyVar; --возвращаемое значение функции
END; -- конец тела функции
go

