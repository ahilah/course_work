
CREATE FUNCTION Hello1(@string varchar(20)) -- создать функцию
RETURNS varchar(30)
-- объявляем тип возвращаемого значения
AS
BEGIN -- начало тела функции
DECLARE @NewString varchar(30) = TRIM(@string)
RETURN '%' + @NewString + '%'; --возвращаемое значение функции
END; -- конец тела функции
go

